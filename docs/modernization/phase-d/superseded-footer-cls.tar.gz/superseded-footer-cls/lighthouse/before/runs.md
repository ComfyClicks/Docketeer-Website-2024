# Individual Lighthouse runs

Local immutable build; URL recorded in reports. All times milliseconds, except CLS (unitless). Scores 0–100.

|Profile/run|UTC timestamp|Performance|Accessibility|Best Practices|SEO|FCP ms|LCP ms|CLS|TBT ms|SI ms|
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|mobile/home-1.report|2026-11-17T22:14:04.830Z|89|100|100|83|1403.097|1763.597|0.208|30.5|1403.097|
|mobile/home-2.report|2026-11-17T22:14:18.338Z|89|100|100|83|1505.607|1853.607|0.208|46|1505.607|
|mobile/home-3.report|2026-11-17T22:14:31.931Z|89|100|100|83|1505.147|1848.147|0.208|36|1505.147|
|desktop/home-1.report|2026-11-17T22:14:45.470Z|92|100|100|83|387.768|661.652|0.181|0|387.768|
|desktop/home-2.report|2026-11-17T22:14:59.388Z|92|100|100|83|378.524|530.024|0.181|0|378.524|
|desktop/home-3.report|2026-11-17T22:15:12.850Z|92|100|100|83|379.614|531.614|0.181|0|379.614|
