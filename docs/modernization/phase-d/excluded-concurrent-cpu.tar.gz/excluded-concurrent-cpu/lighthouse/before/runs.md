# Individual Lighthouse runs

Local immutable build; URL recorded in reports. All times milliseconds, except CLS (unitless). Scores 0–100.

|Profile/run|UTC timestamp|Performance|Accessibility|Best Practices|SEO|FCP ms|LCP ms|CLS|TBT ms|SI ms|
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|mobile/home-1.report|2026-11-17T21:38:33.281Z|70|100|96|83|4505.126|4751.731|0.009|129|4894.335|
|mobile/home-2.report|2026-11-17T21:38:49.890Z|67|100|96|83|3632.615|4821.679|0.001|265|4626.802|
|mobile/home-3.report|2026-11-17T21:39:06.385Z|72|100|96|83|3607.815|4843.56|0|129|4509.129|
|desktop/home-1.report|2026-11-17T21:39:22.970Z|90|100|96|83|731.729|941.302|0.182|30.054|731.729|
|desktop/home-2.report|2026-11-17T21:39:37.127Z|89|100|96|83|754.569|1165.854|0.182|0|754.569|
|desktop/home-3.report|2026-11-17T21:39:51.879Z|90|100|96|83|742.699|994.014|0.181|30|742.699|
